/**
 * SACAB TV - Official Website Scripts
 * Handles config, downloads, admin, animations, and interactivity
 */

(function () {
  'use strict';

  // ========== DEFAULT CONFIG ==========
  const DEFAULT_CONFIG = {
    apkUrl: '', // Must be set by admin
    version: '1.0.0',
    fileSize: '45 MB',
    androidMin: 'Android 6.0+',
    announcement: 'Welcome to SACAB TV – Entertainment Without Limits.',
    aboutText: 'SACAB TV is an entertainment platform designed to bring Anime, Korean Dramas and Movies together in one convenient application. Our goal is to provide users with a simple, enjoyable and modern entertainment experience.',
    downloadCount: 0
  };

  const ADMIN_PASSWORD = 'sacab2026'; // Change this in production or via admin if extended

  // ========== STORAGE HELPERS ==========
  function getConfig() {
    try {
      const stored = localStorage.getItem('sacab_config');
      if (stored) {
        return { ...DEFAULT_CONFIG, ...JSON.parse(stored) };
      }
    } catch (e) {
      console.warn('Config load error', e);
    }
    return { ...DEFAULT_CONFIG };
  }

  function saveConfig(config) {
    try {
      localStorage.setItem('sacab_config', JSON.stringify(config));
      return true;
    } catch (e) {
      console.error('Config save error', e);
      return false;
    }
  }

  function isAdminLoggedIn() {
    return sessionStorage.getItem('sacab_admin') === 'true';
  }

  function setAdminLoggedIn(value) {
    if (value) {
      sessionStorage.setItem('sacab_admin', 'true');
    } else {
      sessionStorage.removeItem('sacab_admin');
    }
  }

  // ========== APPLY CONFIG TO PAGE ==========
  function applyConfig() {
    const config = getConfig();

    // Version
    document.querySelectorAll('[data-config="version"]').forEach(el => {
      el.textContent = config.version;
    });

    // File size
    document.querySelectorAll('[data-config="fileSize"]').forEach(el => {
      el.textContent = config.fileSize;
    });

    // Android min
    document.querySelectorAll('[data-config="androidMin"]').forEach(el => {
      el.textContent = config.androidMin;
    });

    // Download count
    document.querySelectorAll('[data-config="downloadCount"]').forEach(el => {
      el.textContent = config.downloadCount.toLocaleString();
    });

    // Announcement if present
    const announceEl = document.getElementById('announcement');
    if (announceEl && config.announcement) {
      announceEl.textContent = config.announcement;
    }

    // About text
    const aboutEl = document.getElementById('about-description');
    if (aboutEl && config.aboutText) {
      aboutEl.innerHTML = config.aboutText.split('\n').map(p => `<p>${p}</p>`).join('');
    }
  }

  // ========== DOWNLOAD HANDLER ==========
  function handleDownload(e) {
    e.preventDefault();
    const config = getConfig();
    const btn = e.currentTarget;

    if (!config.apkUrl || config.apkUrl.trim() === '') {
      showToast('Download link not configured yet. Please check back soon.', false);
      return;
    }

    // Show loading
    btn.classList.add('loading');
    btn.disabled = true;

    // Increment download count
    config.downloadCount = (config.downloadCount || 0) + 1;
    saveConfig(config);
    applyConfig();

    // Trigger download
    const link = document.createElement('a');
    link.href = config.apkUrl;
    link.download = `SACAB-TV-v${config.version}.apk`;
    link.target = '_blank';
    link.rel = 'noopener';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Show success toast
    setTimeout(() => {
      btn.classList.remove('loading');
      btn.disabled = false;
      showToast('Download started! Check your downloads folder.', true);
    }, 800);
  }

  function showToast(message, success = true) {
    let toast = document.getElementById('download-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'download-toast';
      toast.className = 'download-toast';
      document.body.appendChild(toast);
    }

    toast.innerHTML = success
      ? `<span class="check">✓</span><span>${message}</span>`
      : `<span>${message}</span>`;
    toast.classList.add('show');

    setTimeout(() => {
      toast.classList.remove('show');
    }, 4000);
  }

  // ========== NAV & SCROLL ==========
  function initNav() {
    const header = document.querySelector('.header');
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (menuToggle && navLinks) {
      menuToggle.addEventListener('click', () => {
        menuToggle.classList.toggle('active');
        navLinks.classList.toggle('open');
      });

      // Close menu on link click
      navLinks.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
          menuToggle.classList.remove('active');
          navLinks.classList.remove('open');
        });
      });
    }

    // Header scroll effect
    if (header) {
      window.addEventListener('scroll', () => {
        if (window.scrollY > 40) {
          header.classList.add('scrolled');
        } else {
          header.classList.remove('scrolled');
        }
      });
    }

    // Active nav link on scroll
    const sections = document.querySelectorAll('section[id]');
    window.addEventListener('scroll', () => {
      let current = '';
      sections.forEach(section => {
        const top = section.offsetTop - 120;
        if (window.scrollY >= top) {
          current = section.getAttribute('id');
        }
      });
      document.querySelectorAll('.nav-links a').forEach(a => {
        a.classList.remove('active');
        if (a.getAttribute('href') === `#${current}`) {
          a.classList.add('active');
        }
      });
    });
  }

  // ========== REVEAL ANIMATIONS ==========
  function initReveal() {
    const reveals = document.querySelectorAll('.reveal');
    if (!reveals.length) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
    );

    reveals.forEach(el => observer.observe(el));
  }

  // ========== ADMIN PAGE ==========
  function initAdmin() {
    const loginForm = document.getElementById('admin-login-form');
    const loginSection = document.getElementById('admin-login');
    const dashboard = document.getElementById('admin-dashboard');
    const logoutBtn = document.getElementById('admin-logout');

    if (!loginForm) return; // Not on admin page

    // Check if already logged in
    if (isAdminLoggedIn()) {
      showDashboard();
    }

    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const password = document.getElementById('admin-password').value;
      if (password === ADMIN_PASSWORD) {
        setAdminLoggedIn(true);
        showDashboard();
      } else {
        const err = document.getElementById('login-error');
        if (err) {
          err.textContent = 'Incorrect password. Please try again.';
          err.style.display = 'block';
        }
      }
    });

    if (logoutBtn) {
      logoutBtn.addEventListener('click', () => {
        setAdminLoggedIn(false);
        if (loginSection) loginSection.style.display = 'flex';
        if (dashboard) dashboard.classList.remove('active');
      });
    }

    function showDashboard() {
      if (loginSection) loginSection.style.display = 'none';
      if (dashboard) {
        dashboard.classList.add('active');
        populateAdminForm();
      }
    }

    function populateAdminForm() {
      const config = getConfig();
      const fields = {
        'admin-apk-url': config.apkUrl,
        'admin-version': config.version,
        'admin-filesize': config.fileSize,
        'admin-android': config.androidMin,
        'admin-announcement': config.announcement,
        'admin-about': config.aboutText
      };

      Object.keys(fields).forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = fields[id] || '';
      });

      // Download count display
      const countEl = document.getElementById('admin-download-count');
      if (countEl) countEl.textContent = (config.downloadCount || 0).toLocaleString();
    }

    // Save handlers
    const saveBtns = document.querySelectorAll('[data-save]');
    saveBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const config = getConfig();
        const section = btn.getAttribute('data-save');

        if (section === 'download') {
          config.apkUrl = document.getElementById('admin-apk-url').value.trim();
          config.version = document.getElementById('admin-version').value.trim() || '1.0.0';
          config.fileSize = document.getElementById('admin-filesize').value.trim() || '45 MB';
          config.androidMin = document.getElementById('admin-android').value.trim() || 'Android 6.0+';
        } else if (section === 'content') {
          config.announcement = document.getElementById('admin-announcement').value.trim();
          config.aboutText = document.getElementById('admin-about').value.trim();
        }

        if (saveConfig(config)) {
          const msg = btn.parentElement.querySelector('.admin-message');
          if (msg) {
            msg.textContent = 'Saved successfully!';
            msg.classList.add('show');
            setTimeout(() => msg.classList.remove('show'), 3000);
          }
          // Update download count display
          const countEl = document.getElementById('admin-download-count');
          if (countEl) countEl.textContent = (config.downloadCount || 0).toLocaleString();
        }
      });
    });

    // Reset download count (optional)
    const resetCountBtn = document.getElementById('reset-download-count');
    if (resetCountBtn) {
      resetCountBtn.addEventListener('click', () => {
        if (confirm('Reset download count to 0?')) {
          const config = getConfig();
          config.downloadCount = 0;
          saveConfig(config);
          const countEl = document.getElementById('admin-download-count');
          if (countEl) countEl.textContent = '0';
        }
      });
    }
  }

  // ========== INIT ==========
  document.addEventListener('DOMContentLoaded', () => {
    applyConfig();
    initNav();
    initReveal();
    initAdmin();

    // Bind download buttons
    document.querySelectorAll('[data-download]').forEach(btn => {
      btn.addEventListener('click', handleDownload);
    });

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
          e.preventDefault();
          target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      });
    });
  });

  // Expose for debugging if needed
  window.SACAB = { getConfig, saveConfig, applyConfig };
})();