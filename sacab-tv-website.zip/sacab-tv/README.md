# SACAB TV – Official Download Website

Premium black & yellow cinematic landing page for the SACAB TV Android entertainment app.

## Features

- Modern, responsive design (mobile, tablet, desktop)
- Official logo and brand colors (Bright Yellow #FFD400 + Deep Black)
- Hero section with phone mockup
- Real APK download (URL configured via Admin)
- Features, App Preview, How to Install, About sections
- Footer with Privacy, Terms, Contact
- Secure Admin Dashboard (client-side)
  - Set APK download URL
  - Update version, file size, Android compatibility
  - Edit announcement and About text
  - View / reset local download count

## Quick Start

1. Open `index.html` in a browser, or serve the folder with any static server:
   ```bash
   python3 -m http.server 8080
   ```
2. Go to `/admin.html`
3. Login with password: **`sacab2026`**
4. Paste your real APK direct download URL and save.

## Changing the Admin Password

Edit `js/main.js` and change the constant:

```js
const ADMIN_PASSWORD = 'sacab2026';
```

## Production Notes

- This is a fully static site. Download counts and settings use `localStorage` (per-browser).
- For global download statistics and a more secure admin, connect a simple backend (Node/Express, PHP, etc.) that stores the config and increments counts.
- Always host the APK on a reliable CDN or storage (Google Drive direct link, Firebase, Cloudflare R2, your own server, etc.) and paste the direct HTTPS URL in the admin panel.
- Update the Privacy Policy and Terms pages with your actual legal contact details before going live.

## File Structure

```
sacab-tv/
├── index.html          # Main landing page
├── admin.html          # Admin dashboard
├── css/styles.css      # All styles
├── js/main.js          # Config, download, admin logic
├── assets/logo.jpg     # Official logo
└── pages/
    ├── privacy.html
    ├── terms.html
    └── contact.html
```

## Brand Colors

| Role            | Hex       |
|-----------------|-----------|
| Primary         | `#FFD400` |
| Secondary       | `#080808` |
| Background      | `#101010` |
| Text            | `#FFFFFF` |
| Secondary text  | `#BDBDBD` |

---

© 2026 SACAB TV. All Rights Reserved.
